
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
// import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
// import javafx.scene.control.Label;
// import javafx.scene.control.TextField;

import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import java.io.IOException;


public class Main extends Application {


    
    
    public boolean bool=true;
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primarystage) throws IOException {
        try {
            Parent root=FXMLLoader.load(getClass().getResource("mainmenu.fxml"));
            Scene scene=new Scene(root);
            primarystage.setScene(scene);
            primarystage.setHeight(600);
            primarystage.setWidth(1200);
            primarystage.setResizable(false);
            Image icon = new Image("C:/Users/user/Desktop/AP_Project/AP_Project/src/Images/icon.jpg");
            primarystage.getIcons().add(icon);
            primarystage.show();
            primarystage.setOnCloseRequest(event -> logout(primarystage));
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        


        
    }
    public void logout(Stage primarystage){
        Alert a =new Alert(AlertType.CONFIRMATION);
        a.setTitle("Exit");
        a.setHeaderText("You are about to exit");
        a.setContentText("Are you sure you want to exit?");
        if(a.showAndWait().get()==ButtonType.OK){
            
            System.out.println("logged out");
            primarystage.close();


        }



       
    }
    


}